package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ExercicioActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio4);

        EditText etNome = findViewById(R.id.etNome);
        Button btnGerarCheckboxes = findViewById(R.id.btnGerarCheckboxes);
        LinearLayout llCheckboxes = findViewById(R.id.llCheckboxes);

        btnGerarCheckboxes.setOnClickListener(view -> {
            llCheckboxes.removeAllViews(); // Limpa qualquer checkbox gerado anteriormente
            String nome = etNome.getText().toString();
            if (!nome.isEmpty()) {
                for (char letra : nome.toCharArray()) {
                    CheckBox checkBox = new CheckBox(this);
                    checkBox.setText(String.valueOf(letra));
                    llCheckboxes.addView(checkBox);
                }
            }
        });
    }
}
