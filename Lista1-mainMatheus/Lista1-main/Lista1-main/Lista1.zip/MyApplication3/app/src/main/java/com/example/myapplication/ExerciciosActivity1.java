package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ExerciciosActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicios1);

        EditText etNome = findViewById(R.id.etNome);
        EditText etIdade = findViewById(R.id.etIdade);
        Button btnVerificar = findViewById(R.id.btnVerificar);
        TextView tvResultado = findViewById(R.id.tvResultado);

        btnVerificar.setOnClickListener(view -> {
            String nome = etNome.getText().toString();
            String idadeStr = etIdade.getText().toString();

            if (!idadeStr.isEmpty()) {
                int idade = Integer.parseInt(idadeStr);
                String resultado = nome + (idade >= 18 ? " é maior de idade." : " é menor de idade.");
                tvResultado.setText(resultado);
            }
        });
    }
}
