package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ExercicioActivity2 extends AppCompatActivity {

    // Definindo as variáveis de interface
    private EditText etNumero1, etNumero2;
    private Button btnSomar, btnSubtrair, btnMultiplicar, btnDividir;
    private TextView tvResultado;
    private String operacao = ""; // Variável para armazenar a operação escolhida

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio2);

        // Inicializando as views
        initializeViews();

        // Criando o listener para os botões
        View.OnClickListener listener = createButtonListener();

        // Associando o listener aos botões
        btnSomar.setOnClickListener(listener);
        btnSubtrair.setOnClickListener(listener);
        btnMultiplicar.setOnClickListener(listener);
        btnDividir.setOnClickListener(listener);
    }

    // Função para inicializar as views
    private void initializeViews() {
        etNumero1 = findViewById(R.id.etNumero1);
        etNumero2 = findViewById(R.id.etNumero2);
        btnSomar = findViewById(R.id.btnSomar);
        btnSubtrair = findViewById(R.id.btnSubtrair);
        btnMultiplicar = findViewById(R.id.btnMultiplicar);
        btnDividir = findViewById(R.id.btnDividir);
        tvResultado = findViewById(R.id.tvResultado);
    }

    // Função para criar o listener dos botões
    private View.OnClickListener createButtonListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Recuperando os números inseridos pelos usuários
                String num1Str = etNumero1.getText().toString();
                String num2Str = etNumero2.getText().toString();

                // Verificando se ambos os campos estão preenchidos
                if (!num1Str.isEmpty() && !num2Str.isEmpty()) {
                    double num1 = Double.parseDouble(num1Str);
                    double num2 = Double.parseDouble(num2Str);
                    double resultado = 0;

                    // Atribuindo a operação dependendo do botão clicado
                    if (view.getId() == R.id.btnSomar) {
                        operacao = "somar";
                    } else if (view.getId() == R.id.btnSubtrair) {
                        operacao = "subtrair";
                    } else if (view.getId() == R.id.btnMultiplicar) {
                        operacao = "multiplicar";
                    } else if (view.getId() == R.id.btnDividir) {
                        operacao = "dividir";
                    }

                    // Usando o while para realizar a operação até que a operação seja completada
                    while (!operacao.isEmpty()) {
                        switch (operacao) {
                            case "somar":
                                resultado = num1 + num2;
                                break;
                            case "subtrair":
                                resultado = num1 - num2;
                                break;
                            case "multiplicar":
                                resultado = num1 * num2;
                                break;
                            case "dividir":
                                if (num2 != 0) {
                                    resultado = num1 / num2;
                                } else {
                                    tvResultado.setText("Erro: Divisão por zero!");
                                    operacao = ""; // Resetando a operação após erro
                                    return;
                                }
                                break;
                        }
                        operacao = ""; // Resetando a operação após realizar
                        tvResultado.setText("Resultado: " + resultado);
                    }
                } else {
                    tvResultado.setText("Por favor, insira ambos os números.");
                }
            }
        };
    }
}

