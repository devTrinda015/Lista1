package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ExercicioActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio5);

        CheckBox cbNotificacoes = findViewById(R.id.cbNotificacoes);
        CheckBox cbModoEscuro = findViewById(R.id.cbModoEscuro);
        CheckBox cbLembrarLogin = findViewById(R.id.cbLembrarLogin);
        Button btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(view -> {
            StringBuilder preferencias = new StringBuilder();

            if (cbNotificacoes.isChecked()) preferencias.append("Receber Notificações\n");
            if (cbModoEscuro.isChecked()) preferencias.append("Modo Escuro\n");
            if (cbLembrarLogin.isChecked()) preferencias.append("Lembrar Login\n");

            if (preferencias.length() > 0) {
                Toast.makeText(this, preferencias.toString(), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Nenhuma preferência foi escolhida", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
