package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ExerciciosActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicios3);

        EditText etNome = findViewById(R.id.etNome);
        EditText etIdade = findViewById(R.id.etIdade);
        EditText etCidade = findViewById(R.id.etCidade);
        EditText etUF = findViewById(R.id.etUF);
        EditText etTelefone = findViewById(R.id.etTelefone);
        EditText etEmail = findViewById(R.id.etEmail);

        RadioButton rbP = findViewById(R.id.rbP);
        RadioButton rbM = findViewById(R.id.rbM);
        RadioButton rbG = findViewById(R.id.rbG);

        CheckBox cbVermelho = findViewById(R.id.cbVermelho);
        CheckBox cbAzul = findViewById(R.id.cbAzul);
        CheckBox cbPreto = findViewById(R.id.cbPreto);

        Button btnCadastrar = findViewById(R.id.btnCadastrar);
        TextView tvResultado = findViewById(R.id.tvResultado);

        btnCadastrar.setOnClickListener(view -> {
            String nome = etNome.getText().toString();
            String idade = etIdade.getText().toString();
            String cidade = etCidade.getText().toString();
            String uf = etUF.getText().toString();
            String telefone = etTelefone.getText().toString();
            String email = etEmail.getText().toString();

            String tamanho = rbP.isChecked() ? "P" : rbM.isChecked() ? "M" : rbG.isChecked() ? "G" : "Não selecionado";

            String cores = "";
            if (cbVermelho.isChecked()) cores += "Vermelho ";
            if (cbAzul.isChecked()) cores += "Azul ";
            if (cbPreto.isChecked()) cores += "Preto ";

            String resultado = "Cadastro: \nNome: " + nome + "\nIdade: " + idade + "\nCidade: " + cidade +
                    "\nUF: " + uf + "\nTelefone: " + telefone + "\nEmail: " + email + "\nTamanho: " + tamanho +
                    "\nCores: " + cores;

            tvResultado.setText(resultado);
            Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
        });
    }
}
